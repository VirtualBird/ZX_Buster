Date Started:	12/22/12
Date Posted:	02/08/13
Date Finished:	N/A

This game was made by Tony.

Uhhhh actually its not done yet so.

idk

um

tomato

look at me bein' all profeshiona-

Oh crap I accidentally left my old image files and gimp stuff in the sprites folder-oh well, lazy.:Nope removed them to reduce file size

wHY IS THERE SO MUCH GIBBERISH HERE AW ah well just ignore this.


~~~~~~~~~~~~~~~~~~~~
~Setup Instructions~
~~~~~~~~~~~~~~~~~~~~


I'm assuming you extracted this from the Archive thingy, if not right click the archive and extract it wherever. The files will extract in their own folder.


Go to that ZX Buster folder and

Double click on the file called "ZX Buster.exe"

Thats it really.


If it doesn't work, then I dunno how to help you there, since I can play this on a Flash Drive at a random library computer. (Me assuming you're using Windows) SDL is cross-platform anyways so it should work.

Also not responsible to any damages to computer if something goes wrong. Which nothing should go wrong anyways. (First time making a game in C++ so I don't know how to do things)

If you can't hear sound, that's because my laptop is kind of breaking and has no sound, so I can't add sound even if I wanted to. (I was planning on getting a new laptop when I have the money... Seriously I kinda need a job or something, I don't even have internet.)


~~~~~~~
~Notes~
~~~~~~~


This application was made in C++, using the SDL (Simple DirectMedia Layer) graphics library.

This program reached 10,000 lines of code yay, or is that a bad thing, oh well

I started programming in C++ with no knowledge of C++ whatsoever on 12/17/12 (aside from whatever little I remember from Java during Highschool)

This game would not be possible without Lazyfoo's tutorials

No idea why I named the game ZX Buster.

I dunno why I zipped this into an archive, I didn't even know how to do that until now